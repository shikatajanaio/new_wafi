<template>
    <div class="card">
        <h4>Riwayat Transfer Gudang</h4>

    </div>
</template>