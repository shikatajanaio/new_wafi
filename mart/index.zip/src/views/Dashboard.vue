<template>
    <div className="card">
        Dashboard
    </div>
</template>
